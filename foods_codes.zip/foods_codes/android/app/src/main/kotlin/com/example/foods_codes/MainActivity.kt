package com.example.foods_codes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
